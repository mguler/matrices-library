import { IMatrix } from "./IMatrix";

export interface IMatrixTranspoze {
    transpoze(matrix: IMatrix): IMatrix;
} 